// ─── Vehicles API Routes ──────────────────────────────────────────────────────
import { Hono } from 'hono'
import { vehicles, bookings, calculateDistance, generateId } from '../data/store'

const vehiclesRoute = new Hono()

// GET /api/vehicles — liste avec filtres optionnels
vehiclesRoute.get('/', (c) => {
  const { city, type, available, lat, lng, radius } = c.req.query()

  let result = [...vehicles]

  if (city) result = result.filter(v => v.city.toLowerCase().includes(city.toLowerCase()))
  if (type) result = result.filter(v => v.type === type)
  if (available !== undefined) result = result.filter(v => v.available === (available === 'true'))

  // Filtre géographique (radius en km)
  if (lat && lng && radius) {
    const userLat = parseFloat(lat)
    const userLng = parseFloat(lng)
    const radiusM = parseFloat(radius) * 1000
    result = result.filter(v => calculateDistance(userLat, userLng, v.lat, v.lng) <= radiusM)
    result = result.map(v => ({
      ...v,
      distanceM: calculateDistance(userLat, userLng, v.lat, v.lng)
    })).sort((a: any, b: any) => a.distanceM - b.distanceM)
  }

  return c.json({ success: true, count: result.length, data: result })
})

// GET /api/vehicles/:id — détail d'un véhicule
vehiclesRoute.get('/:id', (c) => {
  const vehicle = vehicles.find(v => v.id === c.req.param('id'))
  if (!vehicle) return c.json({ success: false, error: 'Véhicule introuvable' }, 404)
  return c.json({ success: true, data: vehicle })
})

// GET /api/vehicles/:id/availability — vérifier disponibilité pour une période
vehiclesRoute.get('/:id/availability', (c) => {
  const { startDate, endDate } = c.req.query()
  const vehicle = vehicles.find(v => v.id === c.req.param('id'))
  if (!vehicle) return c.json({ success: false, error: 'Véhicule introuvable' }, 404)

  const conflicts = bookings.filter(b =>
    b.vehicleId === vehicle.id &&
    b.status !== 'cancelled' &&
    !!(startDate && endDate) &&
    b.startDate <= endDate! && b.endDate >= startDate!
  )

  return c.json({
    success: true,
    available: conflicts.length === 0 && vehicle.available,
    conflicts: conflicts.length,
    vehicle: { id: vehicle.id, name: vehicle.name, gpsStatus: vehicle.gpsStatus }
  })
})

// POST /api/vehicles — ajouter un véhicule (propriétaire)
vehiclesRoute.post('/', async (c) => {
  const body = await c.req.json()

  const newVehicle = {
    id: generateId('v'),
    ...body,
    available: true,
    rating: 0,
    totalRentals: 0,
    gpsStatus: 'online' as const,
    createdAt: new Date().toISOString()
  }
  vehicles.push(newVehicle)
  return c.json({ success: true, data: newVehicle }, 201)
})

export { vehiclesRoute }
