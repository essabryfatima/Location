// ─── Payments API Routes ──────────────────────────────────────────────────────
import { Hono } from 'hono'
import { bookings, vehicles, calculateCommission } from '../data/store'

const paymentsRoute = new Hono()

// POST /api/payments/simulate — simuler un paiement Stripe/PayPal
paymentsRoute.post('/simulate', async (c) => {
  const { bookingId, method, cardLast4 } = await c.req.json()

  const booking = bookings.find(b => b.id === bookingId)
  if (!booking) return c.json({ success: false, error: 'Réservation introuvable' }, 404)
  if (booking.paymentStatus === 'paid') {
    return c.json({ success: false, error: 'Cette réservation est déjà payée' }, 400)
  }

  // Simulation du traitement
  const transactionId = `TXN-${Date.now().toString(36).toUpperCase()}`
  const processingFee = method === 'paypal' ? booking.totalCost * 0.029 + 0.30 : 0

  booking.paymentStatus = 'paid'
  booking.paymentMethod = method || 'card'
  booking.status = 'confirmed'

  const vehicle = vehicles.find(v => v.id === booking.vehicleId)

  return c.json({
    success: true,
    transaction: {
      id: transactionId,
      bookingId,
      amount: booking.totalCost,
      currency: 'MAD',
      method,
      cardLast4: cardLast4 || null,
      processingFee: Math.round(processingFee * 100) / 100,
      status: 'approved',
      timestamp: new Date().toISOString()
    },
    booking: {
      id: booking.id,
      qrCode: booking.qrCode,
      status: booking.status,
      vehicle: vehicle ? { name: vehicle.name, lat: vehicle.lat, lng: vehicle.lng } : null
    },
    message: `Paiement de ${booking.totalCost} MAD accepté via ${method}.`
  })
})

// GET /api/payments/summary — récapitulatif financier (dashboard propriétaire)
paymentsRoute.get('/summary', (c) => {
  const { ownerId } = c.req.query()

  const ownerVehicleIds = ownerId
    ? vehicles.filter(v => v.ownerId === ownerId).map(v => v.id)
    : vehicles.map(v => v.id)

  const relevantBookings = bookings.filter(b =>
    ownerVehicleIds.includes(b.vehicleId) && b.paymentStatus === 'paid'
  )

  const totalRevenue = relevantBookings.reduce((sum, b) => sum + b.baseCost, 0)
  const totalCommissions = relevantBookings.reduce((sum, b) => sum + b.commissionAmount, 0)
  const totalTransactions = relevantBookings.length
  const avgBookingValue = totalTransactions > 0 ? totalRevenue / totalTransactions : 0

  const byVehicle = ownerVehicleIds.map(vid => {
    const v = vehicles.find(v => v.id === vid)
    const vBookings = relevantBookings.filter(b => b.vehicleId === vid)
    return {
      vehicleId: vid,
      vehicleName: v?.name || '',
      revenue: vBookings.reduce((s, b) => s + b.baseCost, 0),
      bookings: vBookings.length,
      commissions: vBookings.reduce((s, b) => s + b.commissionAmount, 0)
    }
  }).filter(r => r.bookings > 0)

  return c.json({
    success: true,
    data: {
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      totalCommissions: Math.round(totalCommissions * 100) / 100,
      netRevenue: Math.round((totalRevenue - totalCommissions) * 100) / 100,
      totalTransactions,
      avgBookingValue: Math.round(avgBookingValue * 100) / 100,
      byVehicle
    }
  })
})

// GET /api/payments/commission-calc — calculateur de commission
paymentsRoute.get('/commission-calc', (c) => {
  const { vehicleId, startDate, endDate, startTime, endTime } = c.req.query()

  const vehicle = vehicles.find(v => v.id === vehicleId)
  if (!vehicle) return c.json({ success: false, error: 'Véhicule introuvable' }, 404)

  if (!startDate || !endDate) {
    return c.json({ success: false, error: 'Dates requises' }, 400)
  }

  const start = new Date(`${startDate}T${startTime || '09:00'}`)
  const end = new Date(`${endDate}T${endTime || '09:00'}`)
  const diffMs = end.getTime() - start.getTime()
  const totalHours = Math.ceil(diffMs / (1000 * 60 * 60))
  const totalDays = Math.floor(totalHours / 24)
  const baseCost = totalDays > 0
    ? totalDays * vehicle.pricePerDay + (totalHours % 24) * vehicle.pricePerHour
    : totalHours * vehicle.pricePerHour

  const now = new Date()
  const hoursUntilStart = (start.getTime() - now.getTime()) / (1000 * 60 * 60)
  const isAdvance = hoursUntilStart >= 24

  const { rate, amount } = calculateCommission(baseCost, isAdvance, totalHours)
  const total = baseCost + amount

  return c.json({
    success: true,
    data: {
      vehicle: { id: vehicle.id, name: vehicle.name },
      duration: { totalHours, totalDays },
      pricing: {
        pricePerDay: vehicle.pricePerDay,
        pricePerHour: vehicle.pricePerHour,
        baseCost: Math.round(baseCost * 100) / 100,
        isAdvanceBooking: isAdvance,
        commissionRate: rate,
        commissionLabel: rate > 0 ? `${(rate * 100).toFixed(0)}% (réservation avancée >24h)` : 'Aucune commission',
        commissionAmount: Math.round(amount * 100) / 100,
        totalCost: Math.round(total * 100) / 100,
        currency: 'MAD'
      }
    }
  })
})

export { paymentsRoute }
