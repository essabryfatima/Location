// ─── GPS / Location API Routes ────────────────────────────────────────────────
import { Hono } from 'hono'
import { vehicles, gpsAlerts, calculateDistance, generateId, type GpsAlert } from '../data/store'

const gpsRoute = new Hono()

// GET /api/gps/alerts — toutes les alertes GPS
gpsRoute.get('/alerts', (c) => {
  const { vehicleId, resolved } = c.req.query()
  let result = [...gpsAlerts]
  if (vehicleId) result = result.filter(a => a.vehicleId === vehicleId)
  if (resolved !== undefined) result = result.filter(a => a.resolved === (resolved === 'true'))
  return c.json({ success: true, count: result.length, data: result })
})

// POST /api/gps/validate — valider la position d'un véhicule
gpsRoute.post('/validate', async (c) => {
  const { vehicleId, deviceLat, deviceLng } = await c.req.json()

  const vehicle = vehicles.find(v => v.id === vehicleId)
  if (!vehicle) return c.json({ success: false, error: 'Véhicule introuvable' }, 404)

  const distance = calculateDistance(deviceLat, deviceLng, vehicle.lat, vehicle.lng)
  const threshold = 500 // metres

  let status: 'ok' | 'warning' | 'mismatch' = 'ok'
  let message = 'Position vérifiée — tout est correct'

  if (distance > threshold * 4) {
    status = 'mismatch'
    message = `Écart important détecté : ${distance}m entre votre position et le véhicule`
    vehicle.gpsStatus = 'warning'

    // Créer une alerte GPS
    const alert: GpsAlert = {
      id: generateId('g'),
      vehicleId,
      type: 'mismatch',
      description: message,
      vehicleLat: vehicle.lat,
      vehicleLng: vehicle.lng,
      expectedLat: deviceLat,
      expectedLng: deviceLng,
      distance,
      resolved: false,
      createdAt: new Date().toISOString()
    }
    gpsAlerts.push(alert)
  } else if (distance > threshold) {
    status = 'warning'
    message = `Vous êtes à ${distance}m du véhicule — vérifiez votre itinéraire`
  }

  return c.json({
    success: true,
    status,
    message,
    distance,
    vehicle: {
      id: vehicle.id,
      name: vehicle.name,
      lat: vehicle.lat,
      lng: vehicle.lng,
      gpsStatus: vehicle.gpsStatus
    },
    directions: status !== 'ok' ? {
      googleMaps: `https://www.google.com/maps/dir/${deviceLat},${deviceLng}/${vehicle.lat},${vehicle.lng}`,
      wazeUrl: `https://waze.com/ul?ll=${vehicle.lat},${vehicle.lng}&navigate=yes`
    } : null
  })
})

// PATCH /api/gps/alerts/:id/resolve — résoudre une alerte
gpsRoute.patch('/alerts/:id/resolve', async (c) => {
  const alert = gpsAlerts.find(a => a.id === c.req.param('id'))
  if (!alert) return c.json({ success: false, error: 'Alerte introuvable' }, 404)

  alert.resolved = true
  alert.type = 'resolved'

  const vehicle = vehicles.find(v => v.id === alert.vehicleId)
  if (vehicle) vehicle.gpsStatus = 'online'

  return c.json({ success: true, data: alert, message: 'Alerte résolue.' })
})

// GET /api/gps/vehicles — positions de tous les véhicules (pour la carte)
gpsRoute.get('/vehicles', (c) => {
  const positions = vehicles.map(v => ({
    id: v.id,
    name: v.name,
    type: v.type,
    lat: v.lat,
    lng: v.lng,
    city: v.city,
    available: v.available,
    gpsStatus: v.gpsStatus,
    pricePerDay: v.pricePerDay,
    pricePerHour: v.pricePerHour,
    rating: v.rating,
    image: v.image
  }))
  return c.json({ success: true, data: positions })
})

export { gpsRoute }
