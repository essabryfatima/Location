// ─── Bookings API Routes ──────────────────────────────────────────────────────
import { Hono } from 'hono'
import {
  bookings, vehicles, generateId, calculateCommission, generateQRCode,
  type Booking
} from '../data/store'

const bookingsRoute = new Hono()

// GET /api/bookings — liste des réservations
bookingsRoute.get('/', (c) => {
  const { userId, vehicleId, status } = c.req.query()
  let result = [...bookings]
  if (userId) result = result.filter(b => b.userId === userId)
  if (vehicleId) result = result.filter(b => b.vehicleId === vehicleId)
  if (status) result = result.filter(b => b.status === status)
  return c.json({ success: true, count: result.length, data: result })
})

// GET /api/bookings/:id
bookingsRoute.get('/:id', (c) => {
  const booking = bookings.find(b => b.id === c.req.param('id'))
  if (!booking) return c.json({ success: false, error: 'Réservation introuvable' }, 404)

  const vehicle = vehicles.find(v => v.id === booking.vehicleId)
  return c.json({ success: true, data: { ...booking, vehicle } })
})

// POST /api/bookings — créer une réservation
bookingsRoute.post('/', async (c) => {
  const body = await c.req.json()
  const {
    vehicleId, userName, userEmail, userPhone,
    startDate, endDate, startTime, endTime,
    paymentMethod = 'card', notes = ''
  } = body

  // Validation
  if (!vehicleId || !userName || !userEmail || !startDate || !endDate) {
    return c.json({ success: false, error: 'Champs obligatoires manquants' }, 400)
  }

  const vehicle = vehicles.find(v => v.id === vehicleId)
  if (!vehicle) return c.json({ success: false, error: 'Véhicule introuvable' }, 404)
  if (!vehicle.available) return c.json({ success: false, error: 'Véhicule non disponible' }, 400)

  // Calcul durée
  const start = new Date(`${startDate}T${startTime || '09:00'}`)
  const end = new Date(`${endDate}T${endTime || '09:00'}`)
  const diffMs = end.getTime() - start.getTime()
  if (diffMs <= 0) return c.json({ success: false, error: 'La date de fin doit être après le début' }, 400)

  const totalHours = Math.ceil(diffMs / (1000 * 60 * 60))
  const totalDays = Math.floor(totalHours / 24)
  const baseCost = totalDays > 0
    ? totalDays * vehicle.pricePerDay + (totalHours % 24) * vehicle.pricePerHour
    : totalHours * vehicle.pricePerHour

  // Réservation avancée : plus de 24h à l'avance
  const now = new Date()
  const hoursUntilStart = (start.getTime() - now.getTime()) / (1000 * 60 * 60)
  const isAdvanceBooking = hoursUntilStart >= 24

  // Commission
  const { rate: commissionRate, amount: commissionAmount } =
    calculateCommission(baseCost, isAdvanceBooking, totalHours)

  const totalCost = Math.round((baseCost + commissionAmount) * 100) / 100

  // Vérification conflits
  const conflict = bookings.find(b =>
    b.vehicleId === vehicleId &&
    b.status !== 'cancelled' &&
    b.startDate <= endDate && b.endDate >= startDate
  )
  if (conflict) return c.json({ success: false, error: 'Véhicule déjà réservé pour cette période' }, 409)

  const id = generateId('b')
  const newBooking: Booking = {
    id,
    vehicleId, userId: `u${Date.now()}`,
    userName, userEmail, userPhone,
    startDate, endDate,
    startTime: startTime || '09:00',
    endTime: endTime || '09:00',
    totalHours, totalDays, baseCost,
    commissionRate, commissionAmount, totalCost,
    status: 'pending',
    paymentStatus: 'pending',
    paymentMethod,
    qrCode: generateQRCode(id),
    contractUrl: `/contracts/${id}.pdf`,
    createdAt: new Date().toISOString(),
    isAdvanceBooking,
    pickupLat: vehicle.lat,
    pickupLng: vehicle.lng,
    notes
  }

  bookings.push(newBooking)

  return c.json({
    success: true,
    data: newBooking,
    message: `Réservation créée ! Commission ${isAdvanceBooking ? (commissionRate * 100).toFixed(0) + '%' : '0%'} appliquée.`
  }, 201)
})

// PATCH /api/bookings/:id/confirm — confirmer & payer
bookingsRoute.patch('/:id/confirm', async (c) => {
  const booking = bookings.find(b => b.id === c.req.param('id'))
  if (!booking) return c.json({ success: false, error: 'Réservation introuvable' }, 404)

  booking.status = 'confirmed'
  booking.paymentStatus = 'paid'

  // Marquer véhicule indisponible si démarre aujourd'hui
  const today = new Date().toISOString().split('T')[0]
  if (booking.startDate === today) {
    const v = vehicles.find(v => v.id === booking.vehicleId)
    if (v) v.available = false
  }

  return c.json({ success: true, data: booking, message: 'Réservation confirmée et paiement traité.' })
})

// PATCH /api/bookings/:id/cancel — annuler
bookingsRoute.patch('/:id/cancel', async (c) => {
  const booking = bookings.find(b => b.id === c.req.param('id'))
  if (!booking) return c.json({ success: false, error: 'Réservation introuvable' }, 404)
  if (booking.status === 'active') return c.json({ success: false, error: 'Impossible d\'annuler une location active' }, 400)

  booking.status = 'cancelled'
  if (booking.paymentStatus === 'paid') booking.paymentStatus = 'refunded'

  const v = vehicles.find(v => v.id === booking.vehicleId)
  if (v) v.available = true

  return c.json({ success: true, data: booking, message: 'Réservation annulée.' })
})

export { bookingsRoute }
