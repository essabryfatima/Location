import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { logger } from 'hono/logger'
import { vehiclesRoute } from './routes/vehicles'
import { bookingsRoute } from './routes/bookings'
import { gpsRoute } from './routes/gps'
import { paymentsRoute } from './routes/payments'
import { vehicles, bookings, gpsAlerts, owners } from './data/store'

const app = new Hono()

app.use('*', logger())
app.use('/api/*', cors())

// ─── Mount API Routes ─────────────────────────────────────────────────────────
app.route('/api/vehicles', vehiclesRoute)
app.route('/api/bookings', bookingsRoute)
app.route('/api/gps', gpsRoute)
app.route('/api/payments', paymentsRoute)

// ─── API: Stats for dashboard ─────────────────────────────────────────────────
app.get('/api/stats', (c) => {
  const totalVehicles = vehicles.length
  const availableVehicles = vehicles.filter(v => v.available).length
  const activeBookings = bookings.filter(b => b.status === 'active' || b.status === 'confirmed').length
  const totalRevenue = bookings
    .filter(b => b.paymentStatus === 'paid')
    .reduce((s, b) => s + b.totalCost, 0)
  const gpsWarnings = gpsAlerts.filter(a => !a.resolved).length

  return c.json({
    success: true,
    data: {
      totalVehicles,
      availableVehicles,
      activeBookings,
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      gpsWarnings,
      totalOwners: owners.length
    }
  })
})

// ─── Frontend HTML ────────────────────────────────────────────────────────────
app.get('*', (c) => {
  return c.html(`<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>SmartRent – Location Intelligente</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    :root {
      --primary: #6366f1;
      --primary-dark: #4f46e5;
      --secondary: #10b981;
      --accent: #f59e0b;
      --danger: #ef4444;
    }
    * { box-sizing: border-box; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f8fafc; }

    /* ── Scrollbar ── */
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: #f1f5f9; }
    ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 9999px; }

    /* ── Sidebar ── */
    .sidebar { width: 240px; min-height: 100vh; background: linear-gradient(180deg, #1e1b4b 0%, #312e81 100%); transition: width .3s; }
    .sidebar.collapsed { width: 68px; }
    .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; border-radius: 10px; cursor: pointer; transition: all .2s; color: #c7d2fe; font-size: 14px; }
    .nav-item:hover, .nav-item.active { background: rgba(99,102,241,.35); color: #fff; }
    .nav-item i { width: 20px; text-align: center; font-size: 16px; flex-shrink: 0; }

    /* ── Cards ── */
    .card { background: white; border-radius: 16px; box-shadow: 0 1px 3px rgba(0,0,0,.08), 0 4px 12px rgba(0,0,0,.04); }
    .stat-card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.08); }

    /* ── Vehicle Card ── */
    .vehicle-card { background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.08); transition: transform .2s, box-shadow .2s; cursor: pointer; }
    .vehicle-card:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(0,0,0,.12); }
    .vehicle-card .badge { font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 20px; }

    /* ── Map placeholder ── */
    .map-container { background: linear-gradient(135deg, #e0e7ff 0%, #dbeafe 100%); border-radius: 16px; position: relative; overflow: hidden; }
    .map-pin { position: absolute; transform: translate(-50%, -100%); cursor: pointer; }
    .map-pin .pin { width: 36px; height: 36px; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 8px rgba(0,0,0,.25); transition: transform .2s; }
    .map-pin:hover .pin { transform: rotate(-45deg) scale(1.2); }
    .map-pin .pin i { transform: rotate(45deg); font-size: 14px; color: white; }
    .map-pin.available .pin { background: var(--secondary); }
    .map-pin.unavailable .pin { background: #94a3b8; }

    /* ── Modal ── */
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 50; display: flex; align-items: center; justify-content: center; padding: 16px; opacity: 0; pointer-events: none; transition: opacity .25s; }
    .modal-overlay.open { opacity: 1; pointer-events: all; }
    .modal { background: white; border-radius: 20px; width: 100%; max-width: 540px; max-height: 90vh; overflow-y: auto; transform: scale(.95); transition: transform .25s; }
    .modal-overlay.open .modal { transform: scale(1); }

    /* ── Steps ── */
    .step { display: flex; align-items: center; gap: 8px; }
    .step-circle { width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; }
    .step-line { flex: 1; height: 2px; background: #e2e8f0; }
    .step.done .step-circle { background: var(--secondary); color: white; }
    .step.active .step-circle { background: var(--primary); color: white; }
    .step.pending .step-circle { background: #e2e8f0; color: #94a3b8; }

    /* ── QR Code ── */
    .qr-box { background: white; border: 3px solid #1e1b4b; border-radius: 12px; padding: 20px; display: inline-flex; flex-direction: column; align-items: center; gap: 8px; }
    .qr-grid { display: grid; grid-template-columns: repeat(10, 1fr); gap: 2px; }
    .qr-cell { width: 14px; height: 14px; border-radius: 2px; }

    /* ── GPS status ── */
    .gps-dot { width: 8px; height: 8px; border-radius: 50%; animation: pulse 2s infinite; }
    .gps-dot.online { background: var(--secondary); }
    .gps-dot.offline { background: var(--danger); animation: none; }
    .gps-dot.warning { background: var(--accent); }
    @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: .4; } }

    /* ── Tab content ── */
    .tab-content { display: none; }
    .tab-content.active { display: block; }

    /* ── Input ── */
    input, select, textarea {
      width: 100%; padding: 10px 14px; border: 1.5px solid #e2e8f0; border-radius: 10px;
      font-size: 14px; outline: none; transition: border-color .2s;
      background: white; color: #1e293b;
    }
    input:focus, select:focus, textarea:focus { border-color: var(--primary); }
    label { font-size: 13px; font-weight: 600; color: #374151; display: block; margin-bottom: 4px; }

    /* ── Button ── */
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; transition: all .2s; }
    .btn-primary { background: var(--primary); color: white; }
    .btn-primary:hover { background: var(--primary-dark); transform: translateY(-1px); }
    .btn-success { background: var(--secondary); color: white; }
    .btn-success:hover { background: #059669; }
    .btn-danger { background: var(--danger); color: white; }
    .btn-outline { background: transparent; border: 1.5px solid var(--primary); color: var(--primary); }
    .btn:disabled { opacity: .5; cursor: not-allowed; transform: none !important; }

    /* ── Toast ── */
    .toast { position: fixed; bottom: 24px; right: 24px; padding: 14px 20px; border-radius: 12px; color: white; font-size: 14px; font-weight: 600; z-index: 100; display: flex; align-items: center; gap: 10px; transform: translateX(200%); transition: transform .35s cubic-bezier(0.175,0.885,0.32,1.275); max-width: 380px; box-shadow: 0 8px 24px rgba(0,0,0,.2); }
    .toast.show { transform: translateX(0); }
    .toast.success { background: linear-gradient(135deg, #10b981, #059669); }
    .toast.error { background: linear-gradient(135deg, #ef4444, #dc2626); }
    .toast.info { background: linear-gradient(135deg, #6366f1, #4f46e5); }
    .toast.warning { background: linear-gradient(135deg, #f59e0b, #d97706); }

    /* ── Loader ── */
    .loader { display: inline-block; width: 20px; height: 20px; border: 2px solid rgba(255,255,255,.3); border-top-color: white; border-radius: 50%; animation: spin .7s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* ── Responsive ── */
    @media (max-width: 768px) {
      .sidebar { position: fixed; z-index: 40; left: -240px; transition: left .3s; }
      .sidebar.mobile-open { left: 0; }
      .main-content { margin-left: 0 !important; }
    }

    /* ── Type icon colors ── */
    .type-car { color: #6366f1; }
    .type-bike { color: #f59e0b; }
    .type-scooter { color: #10b981; }
    .type-van { color: #3b82f6; }

    .chip { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
    .chip-indigo { background: #e0e7ff; color: #4338ca; }
    .chip-green { background: #dcfce7; color: #15803d; }
    .chip-red { background: #fee2e2; color: #b91c1c; }
    .chip-amber { background: #fef3c7; color: #92400e; }
    .chip-blue { background: #dbeafe; color: #1d4ed8; }
    .chip-gray { background: #f1f5f9; color: #475569; }

    .divider { height: 1px; background: #f1f5f9; margin: 16px 0; }

    /* ── Dashboard metric ── */
    .metric-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 22px; }
  </style>
</head>
<body class="flex overflow-hidden" style="height:100vh">

<!-- ═══════════ SIDEBAR ═══════════ -->
<aside class="sidebar" id="sidebar">
  <div class="p-4 flex items-center gap-3 mb-2" style="border-bottom:1px solid rgba(255,255,255,.1)">
    <div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
      <i class="fas fa-car text-white" style="font-size:18px"></i>
    </div>
    <div class="nav-label">
      <div class="text-white font-bold text-lg leading-none">SmartRent</div>
      <div style="color:#a5b4fc;font-size:11px">Location Intelligente</div>
    </div>
  </div>
  <nav class="p-3 flex flex-col gap-1">
    <div class="nav-item active" onclick="showTab('map')" id="nav-map">
      <i class="fas fa-map-marked-alt"></i>
      <span class="nav-label">Carte & Véhicules</span>
    </div>
    <div class="nav-item" onclick="showTab('vehicles')" id="nav-vehicles">
      <i class="fas fa-car-side"></i>
      <span class="nav-label">Mes Réservations</span>
    </div>
    <div class="nav-item" onclick="showTab('booking')" id="nav-booking">
      <i class="fas fa-calendar-plus"></i>
      <span class="nav-label">Nouvelle Location</span>
    </div>
    <div class="nav-item" onclick="showTab('gps')" id="nav-gps">
      <i class="fas fa-satellite-dish"></i>
      <span class="nav-label">GPS & Alertes</span>
      <span id="gps-badge" class="ml-auto bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5 hidden">!</span>
    </div>
    <div class="nav-item" onclick="showTab('payments')" id="nav-payments">
      <i class="fas fa-credit-card"></i>
      <span class="nav-label">Paiements</span>
    </div>
    <div class="nav-item" onclick="showTab('dashboard')" id="nav-dashboard">
      <i class="fas fa-chart-line"></i>
      <span class="nav-label">Dashboard</span>
    </div>
  </nav>
  <div class="mt-auto p-3" style="border-top:1px solid rgba(255,255,255,.1)">
    <div class="nav-item" style="margin-top:8px">
      <i class="fas fa-cog"></i>
      <span class="nav-label">Paramètres</span>
    </div>
    <div style="color:#a5b4fc;font-size:11px;padding:8px 16px" class="nav-label">v1.0.0 · Morocco</div>
  </div>
</aside>

<!-- ═══════════ MAIN CONTENT ═══════════ -->
<main class="main-content flex-1 overflow-y-auto" style="margin-left:240px" id="mainContent">

  <!-- ── Top bar ── -->
  <header style="background:white;border-bottom:1px solid #f1f5f9;position:sticky;top:0;z-index:30" class="px-6 py-4 flex items-center gap-4">
    <button onclick="toggleSidebar()" class="text-slate-500 hover:text-slate-700 text-lg">
      <i class="fas fa-bars"></i>
    </button>
    <div class="flex-1 relative max-w-md">
      <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm"></i>
      <input type="text" id="globalSearch" placeholder="Rechercher un véhicule, ville..." class="pl-9 py-2" style="border-radius:24px;border-color:#e2e8f0;font-size:13px" oninput="handleSearch(this.value)" />
    </div>
    <div class="flex items-center gap-2 ml-auto">
      <div class="flex items-center gap-2 px-3 py-2 rounded-xl" style="background:#f0fdf4">
        <div class="gps-dot online"></div>
        <span style="font-size:12px;color:#15803d;font-weight:600">GPS Actif</span>
      </div>
      <div class="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);font-size:14px">Y</div>
    </div>
  </header>

  <div class="p-6">

    <!-- ════════════ TAB: CARTE ════════════ -->
    <div class="tab-content active" id="tab-map">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-2xl font-bold text-slate-800">Carte des Véhicules</h1>
          <p class="text-slate-500 text-sm mt-1">Trouvez le véhicule le plus proche de vous</p>
        </div>
        <div class="flex gap-2">
          <select id="filterType" onchange="filterVehicles()" class="py-2 px-3" style="width:auto;border-radius:10px;font-size:13px">
            <option value="">Tous types</option>
            <option value="car">Voitures</option>
            <option value="bike">Motos</option>
            <option value="scooter">Trottinettes</option>
            <option value="van">Utilitaires</option>
          </select>
          <select id="filterCity" onchange="filterVehicles()" class="py-2 px-3" style="width:auto;border-radius:10px;font-size:13px">
            <option value="">Toutes villes</option>
            <option value="Casablanca">Casablanca</option>
            <option value="Rabat">Rabat</option>
            <option value="Marrakech">Marrakech</option>
          </select>
        </div>
      </div>

      <!-- Map + List layout -->
      <div class="grid grid-cols-1 xl:grid-cols-3 gap-6">

        <!-- Map -->
        <div class="xl:col-span-2 map-container" style="height:480px" id="mapContainer">
          <!-- Morocco map SVG background -->
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:.15">
            <i class="fas fa-map" style="font-size:200px;color:#4f46e5"></i>
          </div>
          <div style="position:absolute;top:16px;left:16px;right:16px;display:flex;justify-content:space-between;align-items:center">
            <div class="card px-3 py-2 flex items-center gap-2">
              <i class="fas fa-map-marker-alt text-indigo-500"></i>
              <span style="font-size:13px;font-weight:600;color:#1e293b">Maroc</span>
            </div>
            <div class="card px-3 py-2 flex gap-3" style="font-size:12px">
              <div class="flex items-center gap-1"><div style="width:10px;height:10px;border-radius:50%;background:#10b981"></div><span>Disponible</span></div>
              <div class="flex items-center gap-1"><div style="width:10px;height:10px;border-radius:50%;background:#94a3b8"></div><span>Loué</span></div>
              <div class="flex items-center gap-1"><div style="width:10px;height:10px;border-radius:50%;background:#f59e0b"></div><span>Alerte GPS</span></div>
            </div>
          </div>
          <!-- Vehicle pins will be rendered here -->
          <div id="mapPins"></div>
          <div style="position:absolute;bottom:16px;left:16px;right:16px">
            <div class="card p-3 flex items-center gap-3">
              <i class="fas fa-location-crosshairs text-indigo-500"></i>
              <div style="flex:1">
                <div style="font-size:12px;color:#64748b">Votre position</div>
                <div style="font-size:13px;font-weight:600;color:#1e293b" id="userLocationLabel">Détection en cours...</div>
              </div>
              <button class="btn btn-primary py-2 px-3 text-xs" onclick="detectLocation()">
                <i class="fas fa-crosshairs"></i> Localiser
              </button>
            </div>
          </div>
        </div>

        <!-- Vehicle list -->
        <div style="height:480px;overflow-y:auto;display:flex;flex-direction:column;gap:12px" id="vehicleListSidebar">
          <div class="text-center py-8"><div class="loader" style="border-color:#e2e8f0;border-top-color:#6366f1"></div></div>
        </div>
      </div>

      <!-- All vehicles grid -->
      <div class="mt-8">
        <h2 class="text-xl font-bold text-slate-800 mb-4">Tous les Véhicules <span id="vehicleCount" class="text-slate-400 text-base font-normal"></span></h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" id="vehiclesGrid">
          <div class="col-span-full text-center py-12 text-slate-400">
            <div class="loader" style="border-color:#e2e8f0;border-top-color:#6366f1;width:32px;height:32px;border-width:3px"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- ════════════ TAB: RÉSERVATIONS ════════════ -->
    <div class="tab-content" id="tab-vehicles">
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-2xl font-bold text-slate-800">Mes Réservations</h1>
          <p class="text-slate-500 text-sm mt-1">Gérez vos locations en cours et passées</p>
        </div>
        <button class="btn btn-primary" onclick="showTab('booking')">
          <i class="fas fa-plus"></i> Nouvelle location
        </button>
      </div>
      <div id="bookingsList" class="flex flex-col gap-4">
        <div class="text-center py-12"><div class="loader" style="border-color:#e2e8f0;border-top-color:#6366f1;width:32px;height:32px;border-width:3px"></div></div>
      </div>
    </div>

    <!-- ════════════ TAB: NOUVELLE LOCATION ════════════ -->
    <div class="tab-content" id="tab-booking">
      <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Nouvelle Location</h1>
        <p class="text-slate-500 text-sm mt-1">Réservez un véhicule en quelques étapes</p>
      </div>

      <!-- Steps indicator -->
      <div class="flex items-center gap-2 mb-8 card p-4">
        <div class="step" id="step1-indicator">
          <div class="step-circle active">1</div>
          <span style="font-size:13px;font-weight:600;color:#4f46e5">Choisir le véhicule</span>
        </div>
        <div class="step-line"></div>
        <div class="step" id="step2-indicator">
          <div class="step-circle pending">2</div>
          <span style="font-size:13px;color:#94a3b8">Dates & Horaires</span>
        </div>
        <div class="step-line"></div>
        <div class="step" id="step3-indicator">
          <div class="step-circle pending">3</div>
          <span style="font-size:13px;color:#94a3b8">Vos Informations</span>
        </div>
        <div class="step-line"></div>
        <div class="step" id="step4-indicator">
          <div class="step-circle pending">4</div>
          <span style="font-size:13px;color:#94a3b8">Paiement</span>
        </div>
      </div>

      <!-- Step 1 -->
      <div id="booking-step1" class="card p-6">
        <h2 class="font-bold text-lg text-slate-800 mb-4"><i class="fas fa-car text-indigo-500 mr-2"></i>Sélectionnez un véhicule</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" id="bookingVehicleGrid">
          <div class="col-span-full text-center py-8"><div class="loader" style="border-color:#e2e8f0;border-top-color:#6366f1;width:32px;height:32px;border-width:3px"></div></div>
        </div>
      </div>

      <!-- Step 2 -->
      <div id="booking-step2" class="card p-6 hidden">
        <h2 class="font-bold text-lg text-slate-800 mb-4"><i class="fas fa-calendar text-indigo-500 mr-2"></i>Choisissez vos dates</h2>
        <div id="selectedVehicleInfo" class="p-4 rounded-xl mb-6" style="background:#f0f0ff;border:1.5px solid #c7d2fe"></div>
        <div class="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label>Date de début</label>
            <input type="date" id="startDate" min="" onchange="calculateCost()" />
          </div>
          <div>
            <label>Heure de début</label>
            <input type="time" id="startTime" value="09:00" onchange="calculateCost()" />
          </div>
          <div>
            <label>Date de fin</label>
            <input type="date" id="endDate" min="" onchange="calculateCost()" />
          </div>
          <div>
            <label>Heure de fin</label>
            <input type="time" id="endTime" value="09:00" onchange="calculateCost()" />
          </div>
        </div>
        <!-- Cost preview -->
        <div id="costPreview" class="hidden p-4 rounded-xl" style="background:#f8fafc;border:1.5px solid #e2e8f0">
          <div class="text-sm font-semibold text-slate-600 mb-3">Récapitulatif des coûts</div>
          <div class="flex flex-col gap-2" id="costBreakdown"></div>
        </div>
        <div class="flex justify-between mt-6">
          <button class="btn btn-outline" onclick="goStep(1)"><i class="fas fa-arrow-left"></i> Retour</button>
          <button class="btn btn-primary" onclick="goStep(3)">Continuer <i class="fas fa-arrow-right"></i></button>
        </div>
      </div>

      <!-- Step 3 -->
      <div id="booking-step3" class="card p-6 hidden">
        <h2 class="font-bold text-lg text-slate-800 mb-4"><i class="fas fa-user text-indigo-500 mr-2"></i>Vos informations</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div class="sm:col-span-2">
            <label>Nom complet *</label>
            <input type="text" id="userName" placeholder="Youssef El Mansouri" />
          </div>
          <div>
            <label>Email *</label>
            <input type="email" id="userEmail" placeholder="youssef@example.ma" />
          </div>
          <div>
            <label>Téléphone *</label>
            <input type="tel" id="userPhone" placeholder="+212 6XX XXX XXX" />
          </div>
          <div class="sm:col-span-2">
            <label>Notes (optionnel)</label>
            <textarea id="bookingNotes" rows="2" placeholder="Informations supplémentaires..." style="resize:none"></textarea>
          </div>
        </div>
        <div class="flex justify-between mt-6">
          <button class="btn btn-outline" onclick="goStep(2)"><i class="fas fa-arrow-left"></i> Retour</button>
          <button class="btn btn-primary" onclick="goStep(4)">Continuer <i class="fas fa-arrow-right"></i></button>
        </div>
      </div>

      <!-- Step 4 – Payment -->
      <div id="booking-step4" class="card p-6 hidden">
        <h2 class="font-bold text-lg text-slate-800 mb-4"><i class="fas fa-lock text-indigo-500 mr-2"></i>Paiement sécurisé</h2>
        <div id="finalSummary" class="p-4 rounded-xl mb-6" style="background:#f8fafc;border:1.5px solid #e2e8f0"></div>
        <div class="mb-4">
          <label>Méthode de paiement</label>
          <div class="grid grid-cols-3 gap-3 mt-2">
            <div class="p-3 rounded-xl border-2 border-indigo-500 cursor-pointer text-center" id="pm-card" onclick="selectPayment('card')" style="background:#f0f0ff">
              <i class="fas fa-credit-card text-indigo-500 text-xl mb-1"></i>
              <div style="font-size:12px;font-weight:600;color:#4f46e5">Carte</div>
            </div>
            <div class="p-3 rounded-xl border-2 border-transparent cursor-pointer text-center hover:border-blue-300" id="pm-paypal" onclick="selectPayment('paypal')" style="background:#f8fafc">
              <i class="fab fa-paypal text-blue-500 text-xl mb-1"></i>
              <div style="font-size:12px;font-weight:600;color:#3b82f6">PayPal</div>
            </div>
            <div class="p-3 rounded-xl border-2 border-transparent cursor-pointer text-center hover:border-green-300" id="pm-cash" onclick="selectPayment('cash')" style="background:#f8fafc">
              <i class="fas fa-money-bill-wave text-green-500 text-xl mb-1"></i>
              <div style="font-size:12px;font-weight:600;color:#16a34a">Espèces</div>
            </div>
          </div>
        </div>
        <div id="cardFields" class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <div class="sm:col-span-2">
            <label>Numéro de carte</label>
            <input type="text" id="cardNumber" placeholder="1234 5678 9012 3456" maxlength="19" oninput="formatCard(this)" />
          </div>
          <div>
            <label>Expiration</label>
            <input type="text" id="cardExpiry" placeholder="MM/AA" maxlength="5" />
          </div>
          <div>
            <label>CVV</label>
            <input type="text" id="cardCvv" placeholder="123" maxlength="3" />
          </div>
        </div>
        <div class="flex items-center gap-2 p-3 rounded-xl mb-6" style="background:#f0fdf4;border:1px solid #bbf7d0">
          <i class="fas fa-shield-alt text-green-600"></i>
          <span style="font-size:12px;color:#15803d;font-weight:500">Paiement chiffré SSL 256-bit · Données sécurisées</span>
        </div>
        <div class="flex justify-between">
          <button class="btn btn-outline" onclick="goStep(3)"><i class="fas fa-arrow-left"></i> Retour</button>
          <button class="btn btn-success" id="payBtn" onclick="submitBooking()">
            <i class="fas fa-lock"></i> Confirmer & Payer
          </button>
        </div>
      </div>
    </div>

    <!-- ════════════ TAB: GPS ════════════ -->
    <div class="tab-content" id="tab-gps">
      <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">GPS & Alertes</h1>
        <p class="text-slate-500 text-sm mt-1">Surveillance en temps réel des véhicules</p>
      </div>
      <div class="grid grid-cols-1 xl:grid-cols-3 gap-6">

        <!-- GPS Validator -->
        <div class="card p-6">
          <h2 class="font-bold text-slate-800 mb-4"><i class="fas fa-location-dot text-indigo-500 mr-2"></i>Vérificateur GPS</h2>
          <div class="mb-4">
            <label>Sélectionner le véhicule</label>
            <select id="gpsVehicleSelect">
              <option value="">-- Choisir --</option>
            </select>
          </div>
          <div class="grid grid-cols-2 gap-3 mb-4">
            <div>
              <label>Latitude (vous)</label>
              <input type="number" id="deviceLat" placeholder="33.5731" step="0.0001" />
            </div>
            <div>
              <label>Longitude (vous)</label>
              <input type="number" id="deviceLng" placeholder="-7.5898" step="0.0001" />
            </div>
          </div>
          <button class="btn btn-primary w-full mb-3" onclick="detectAndValidate()">
            <i class="fas fa-crosshairs"></i> Détecter ma position
          </button>
          <button class="btn btn-outline w-full" onclick="validateGPS()">
            <i class="fas fa-check-circle"></i> Valider la position
          </button>
          <div id="gpsResult" class="hidden mt-4 p-4 rounded-xl"></div>
        </div>

        <!-- Vehicle GPS status -->
        <div class="card p-6">
          <h2 class="font-bold text-slate-800 mb-4"><i class="fas fa-signal text-indigo-500 mr-2"></i>Statuts GPS Véhicules</h2>
          <div id="vehicleGPSStatuses" class="flex flex-col gap-3"></div>
        </div>

        <!-- Alerts -->
        <div class="card p-6">
          <h2 class="font-bold text-slate-800 mb-4"><i class="fas fa-triangle-exclamation text-amber-500 mr-2"></i>Alertes Actives</h2>
          <div id="gpsAlertsList" class="flex flex-col gap-3">
            <div class="text-center py-6"><div class="loader" style="border-color:#e2e8f0;border-top-color:#6366f1"></div></div>
          </div>
        </div>
      </div>
    </div>

    <!-- ════════════ TAB: PAYMENTS ════════════ -->
    <div class="tab-content" id="tab-payments">
      <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Paiements & Commissions</h1>
        <p class="text-slate-500 text-sm mt-1">Historique des transactions et calcul des commissions</p>
      </div>
      <div class="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
        <div class="card p-6">
          <h3 class="font-bold text-slate-700 mb-4"><i class="fas fa-calculator text-indigo-500 mr-2"></i>Simulateur de Commission</h3>
          <div class="flex flex-col gap-3">
            <div>
              <label>Véhicule</label>
              <select id="simVehicle" onchange="simulateCommission()">
                <option value="">-- Choisir --</option>
              </select>
            </div>
            <div>
              <label>Date début</label>
              <input type="date" id="simStart" onchange="simulateCommission()" />
            </div>
            <div>
              <label>Date fin</label>
              <input type="date" id="simEnd" onchange="simulateCommission()" />
            </div>
          </div>
          <div id="commissionResult" class="hidden mt-4 p-4 rounded-xl" style="background:#f0f0ff;border:1.5px solid #c7d2fe"></div>
        </div>
        <div class="xl:col-span-2 card p-6">
          <h3 class="font-bold text-slate-700 mb-4"><i class="fas fa-chart-bar text-indigo-500 mr-2"></i>Revenus par Véhicule</h3>
          <canvas id="revenueChart" height="160"></canvas>
        </div>
      </div>

      <!-- Transactions list -->
      <div class="card p-6">
        <h3 class="font-bold text-slate-800 mb-4"><i class="fas fa-list text-indigo-500 mr-2"></i>Transactions Récentes</h3>
        <div id="transactionsList" class="flex flex-col gap-3"></div>
      </div>
    </div>

    <!-- ════════════ TAB: DASHBOARD ════════════ -->
    <div class="tab-content" id="tab-dashboard">
      <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-800">Dashboard Propriétaire</h1>
        <p class="text-slate-500 text-sm mt-1">Vue d'ensemble de votre activité</p>
      </div>
      <!-- Metrics -->
      <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6" id="metricsGrid">
        <div class="stat-card animate-pulse"><div class="h-4 bg-slate-100 rounded mb-2"></div><div class="h-8 bg-slate-100 rounded"></div></div>
      </div>
      <!-- Charts -->
      <div class="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-6">
        <div class="card p-6">
          <h3 class="font-bold text-slate-700 mb-4">Réservations par Statut</h3>
          <canvas id="bookingStatusChart" height="200"></canvas>
        </div>
        <div class="card p-6">
          <h3 class="font-bold text-slate-700 mb-4">Véhicules par Type</h3>
          <canvas id="vehicleTypeChart" height="200"></canvas>
        </div>
      </div>
      <!-- Top vehicles -->
      <div class="card p-6">
        <h3 class="font-bold text-slate-800 mb-4"><i class="fas fa-trophy text-amber-500 mr-2"></i>Top Véhicules</h3>
        <div id="topVehicles" class="flex flex-col gap-3"></div>
      </div>
    </div>

  </div><!-- /p-6 -->
</main>

<!-- ═══════════ VEHICLE DETAIL MODAL ═══════════ -->
<div class="modal-overlay" id="vehicleModal">
  <div class="modal p-6" id="vehicleModalContent"></div>
</div>

<!-- ═══════════ BOOKING CONFIRMATION MODAL ═══════════ -->
<div class="modal-overlay" id="confirmModal">
  <div class="modal p-6" id="confirmModalContent"></div>
</div>

<!-- ═══════════ TOAST ═══════════ -->
<div class="toast" id="toast">
  <i id="toastIcon" class="fas fa-check-circle"></i>
  <span id="toastMsg"></span>
</div>

<script>
// ════════════════════════════════════════════════════════════════════════════
// SmartRent Frontend App
// ════════════════════════════════════════════════════════════════════════════

const API = ''  // same origin
let allVehicles = []
let allBookings = []
let selectedVehicle = null
let currentStep = 1
let selectedPayment = 'card'
let stats = {}
let userLat = null, userLng = null

// ── Toast ─────────────────────────────────────────────────────────────────
function toast(msg, type = 'success') {
  const el = document.getElementById('toast')
  const icon = document.getElementById('toastIcon')
  const msgEl = document.getElementById('toastMsg')
  const icons = { success: 'fa-check-circle', error: 'fa-xmark-circle', info: 'fa-info-circle', warning: 'fa-triangle-exclamation' }
  el.className = \`toast show \${type}\`
  icon.className = \`fas \${icons[type] || icons.success}\`
  msgEl.textContent = msg
  setTimeout(() => el.classList.remove('show'), 4000)
}

// ── Tab navigation ────────────────────────────────────────────────────────
function showTab(tab) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'))
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'))
  document.getElementById(\`tab-\${tab}\`).classList.add('active')
  const nav = document.getElementById(\`nav-\${tab}\`)
  if (nav) nav.classList.add('active')

  if (tab === 'vehicles') loadBookings()
  if (tab === 'gps') loadGPS()
  if (tab === 'payments') loadPayments()
  if (tab === 'dashboard') loadDashboard()
  if (tab === 'booking') { loadBookingVehicles(); goStep(1) }
}

function toggleSidebar() {
  const sb = document.getElementById('sidebar')
  if (window.innerWidth <= 768) { sb.classList.toggle('mobile-open') }
  else {
    sb.classList.toggle('collapsed')
    document.getElementById('mainContent').style.marginLeft = sb.classList.contains('collapsed') ? '68px' : '240px'
  }
}

// ── Load vehicles ─────────────────────────────────────────────────────────
async function loadVehicles(params = {}) {
  try {
    const q = new URLSearchParams(params).toString()
    const res = await axios.get(\`\${API}/api/vehicles\${q ? '?'+q : ''}\`)
    allVehicles = res.data.data
    renderVehiclesGrid()
    renderMapPins()
    renderVehicleSidebar()
    document.getElementById('vehicleCount').textContent = \`(\${allVehicles.length})\`
  } catch(e) { toast('Erreur chargement véhicules', 'error') }
}

function renderVehiclesGrid() {
  const g = document.getElementById('vehiclesGrid')
  if (!allVehicles.length) { g.innerHTML = '<div class="col-span-full text-center py-12 text-slate-400"><i class="fas fa-car-side text-4xl mb-3 block"></i>Aucun véhicule trouvé</div>'; return }
  g.innerHTML = allVehicles.map(v => vehicleCard(v)).join('')
}

function vehicleCard(v) {
  const typeIcon = { car: 'fa-car', bike: 'fa-motorcycle', scooter: 'fa-person-biking', van: 'fa-van-shuttle' }
  const typeColor = { car: 'chip-indigo', bike: 'chip-amber', scooter: 'chip-green', van: 'chip-blue' }
  const gpsColors = { online: 'chip-green', offline: 'chip-red', warning: 'chip-amber' }
  return \`
  <div class="vehicle-card" onclick="openVehicleModal('\${v.id}')">
    <div style="position:relative;height:160px;overflow:hidden">
      <img src="\${v.image}" alt="\${v.name}" style="width:100%;height:100%;object-fit:cover" />
      <div style="position:absolute;top:10px;left:10px">
        <span class="chip \${v.available ? 'chip-green' : 'chip-red'}">
          <i class="fas \${v.available ? 'fa-circle-check' : 'fa-circle-xmark'}" style="font-size:9px"></i>
          \${v.available ? 'Disponible' : 'Loué'}
        </span>
      </div>
      <div style="position:absolute;top:10px;right:10px">
        <span class="chip chip-gray">
          <div class="gps-dot \${v.gpsStatus}" style="width:6px;height:6px"></div>
          GPS
        </span>
      </div>
    </div>
    <div class="p-4">
      <div class="flex items-start justify-between mb-2">
        <div>
          <div class="font-bold text-slate-800" style="font-size:15px">\${v.name}</div>
          <div style="font-size:12px;color:#64748b">\${v.city} · \${v.year}</div>
        </div>
        <div class="text-right">
          <div class="font-bold" style="color:#4f46e5;font-size:16px">\${v.pricePerDay} MAD</div>
          <div style="font-size:11px;color:#94a3b8">/jour</div>
        </div>
      </div>
      <div class="flex items-center gap-2 mb-3">
        <span class="chip \${typeColor[v.type] || 'chip-gray'}"><i class="fas \${typeIcon[v.type] || 'fa-question'}" style="font-size:10px"></i> \${v.type}</span>
        <span class="chip chip-amber"><i class="fas fa-star" style="font-size:9px"></i> \${v.rating}</span>
        <span class="chip chip-gray">\${v.fuelType}</span>
      </div>
      <div class="flex gap-1 flex-wrap">
        \${v.features.slice(0,3).map(f => \`<span style="font-size:10px;background:#f1f5f9;color:#475569;padding:2px 7px;border-radius:20px">\${f}</span>\`).join('')}
      </div>
    </div>
  </div>\`
}

function renderMapPins() {
  // Simple CSS-based map with relative positions
  const container = document.getElementById('mapContainer')
  const W = container.offsetWidth || 600
  const H = container.offsetHeight || 480

  // Morocco bounding box approx
  const minLat=27.6, maxLat=35.9, minLng=-13.2, maxLng=-1.0
  const pinsHtml = allVehicles.map(v => {
    const x = ((v.lng - minLng) / (maxLng - minLng)) * (W - 60) + 20
    const y = ((maxLat - v.lat) / (maxLat - minLat)) * (H - 100) + 20
    const cls = v.gpsStatus === 'warning' ? '' : (v.available ? 'available' : 'unavailable')
    const bg = v.gpsStatus === 'warning' ? '#f59e0b' : (v.available ? '#10b981' : '#94a3b8')
    const icon = { car:'fa-car', bike:'fa-motorcycle', scooter:'fa-person-biking', van:'fa-van-shuttle' }[v.type] || 'fa-car'
    return \`<div class="map-pin \${cls}" style="left:\${x}px;top:\${y}px" onclick="openVehicleModal('\${v.id}')" title="\${v.name}">
      <div class="pin" style="background:\${bg}"><i class="fas \${icon}"></i></div>
    </div>\`
  }).join('')
  document.getElementById('mapPins').innerHTML = pinsHtml
}

function renderVehicleSidebar() {
  const available = allVehicles.filter(v => v.available)
  const typeIcon = { car:'fa-car', bike:'fa-motorcycle', scooter:'fa-person-biking', van:'fa-van-shuttle' }
  document.getElementById('vehicleListSidebar').innerHTML = available.length
    ? available.map(v => \`
      <div onclick="openVehicleModal('\${v.id}')" style="cursor:pointer;border-radius:14px;overflow:hidden;background:white;box-shadow:0 1px 3px rgba(0,0,0,.08);display:flex;gap:0;flex-shrink:0">
        <img src="\${v.image}" style="width:80px;height:80px;object-fit:cover;flex-shrink:0" />
        <div style="padding:10px 12px;flex:1;min-width:0">
          <div style="font-weight:700;font-size:13px;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${v.name}</div>
          <div style="font-size:11px;color:#64748b">\${v.city}</div>
          <div style="font-size:13px;font-weight:700;color:#4f46e5;margin-top:4px">\${v.pricePerDay} MAD/j</div>
        </div>
      </div>\`).join('')
    : '<div class="text-center py-8 text-slate-400" style="font-size:13px">Aucun véhicule disponible</div>'
}

function filterVehicles() {
  const type = document.getElementById('filterType').value
  const city = document.getElementById('filterCity').value
  const params = {}
  if (type) params.type = type
  if (city) params.city = city
  loadVehicles(params)
}

// ── Vehicle Modal ─────────────────────────────────────────────────────────
function openVehicleModal(id) {
  const v = allVehicles.find(x => x.id === id)
  if (!v) return
  const typeIcon = { car:'fa-car', bike:'fa-motorcycle', scooter:'fa-person-biking', van:'fa-van-shuttle' }
  const gpsLabel = { online:'En ligne', offline:'Hors ligne', warning:'Alerte' }
  const gpsChip = { online:'chip-green', offline:'chip-red', warning:'chip-amber' }
  document.getElementById('vehicleModalContent').innerHTML = \`
    <div style="position:relative">
      <button onclick="closeModal('vehicleModal')" style="position:absolute;top:0;right:0;background:none;border:none;cursor:pointer;font-size:20px;color:#94a3b8">
        <i class="fas fa-xmark"></i>
      </button>
      <img src="\${v.image}" alt="\${v.name}" style="width:100%;height:200px;object-fit:cover;border-radius:12px;margin-bottom:16px" />
      <div class="flex items-center justify-between mb-3">
        <div>
          <h2 class="text-xl font-bold text-slate-800">\${v.name}</h2>
          <div style="font-size:13px;color:#64748b">\${v.brand} \${v.model} · \${v.year} · \${v.city}</div>
        </div>
        <div class="text-right">
          <div style="font-size:22px;font-weight:800;color:#4f46e5">\${v.pricePerDay} MAD</div>
          <div style="font-size:11px;color:#94a3b8">par jour · \${v.pricePerHour} MAD/h</div>
        </div>
      </div>
      <div class="flex flex-wrap gap-2 mb-4">
        <span class="chip \${v.available ? 'chip-green' : 'chip-red'}">\${v.available ? 'Disponible' : 'Non disponible'}</span>
        <span class="chip \${gpsChip[v.gpsStatus]}"><div class="gps-dot \${v.gpsStatus}" style="width:6px;height:6px"></div> GPS \${gpsLabel[v.gpsStatus]}</span>
        <span class="chip chip-amber"><i class="fas fa-star" style="font-size:9px"></i> \${v.rating} · \${v.totalRentals} locations</span>
        <span class="chip chip-gray">\${v.licensePlate}</span>
      </div>
      <div class="divider"></div>
      <div style="font-size:13px;font-weight:700;color:#374151;margin-bottom:8px">Équipements</div>
      <div class="flex flex-wrap gap-2 mb-4">
        \${v.features.map(f => \`<span style="background:#f0f0ff;color:#4338ca;font-size:12px;padding:4px 10px;border-radius:20px;font-weight:500">\${f}</span>\`).join('')}
      </div>
      <div class="divider"></div>
      <div class="grid grid-cols-2 gap-3 mb-4" style="font-size:13px">
        <div style="background:#f8fafc;padding:12px;border-radius:12px">
          <i class="fas fa-map-marker-alt text-indigo-400 mr-2"></i>
          <span style="color:#374151">\${v.address}</span>
        </div>
        <div style="background:#f8fafc;padding:12px;border-radius:12px">
          <i class="fas fa-gas-pump text-indigo-400 mr-2"></i>
          <span style="color:#374151">\${v.fuelType}</span>
        </div>
      </div>
      \${v.gpsStatus === 'warning' ? \`
        <div class="flex items-center gap-2 p-3 rounded-xl mb-4" style="background:#fef3c7;border:1px solid #fcd34d">
          <i class="fas fa-triangle-exclamation text-amber-500"></i>
          <span style="font-size:12px;color:#92400e;font-weight:600">Alerte GPS détectée sur ce véhicule</span>
        </div>\` : ''}
      <div class="flex gap-3">
        <a href="https://www.google.com/maps?q=\${v.lat},\${v.lng}" target="_blank" class="btn btn-outline flex-1 justify-center">
          <i class="fas fa-map-marker-alt"></i> Voir sur Maps
        </a>
        \${v.available ? \`<button class="btn btn-primary flex-1 justify-center" onclick="closeModal('vehicleModal');selectVehicleForBooking('\${v.id}')">
          <i class="fas fa-calendar-plus"></i> Réserver
        </button>\` : '<button class="btn flex-1 justify-center" style="background:#e2e8f0;color:#94a3b8;cursor:not-allowed" disabled>Indisponible</button>'}
      </div>
    </div>\`
  document.getElementById('vehicleModal').classList.add('open')
}

function closeModal(id) { document.getElementById(id).classList.remove('open') }
document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', function(e){ if(e.target===this) this.classList.remove('open') }))

// ── Booking Flow ──────────────────────────────────────────────────────────
function loadBookingVehicles() {
  const available = allVehicles.filter(v => v.available)
  document.getElementById('bookingVehicleGrid').innerHTML = available.length
    ? available.map(v => \`
      <div class="vehicle-card \${selectedVehicle?.id===v.id ? 'ring-2 ring-indigo-500' : ''}" onclick="selectVehicleForBooking('\${v.id}');goStep(2)" style="cursor:pointer">
        <img src="\${v.image}" style="width:100%;height:130px;object-fit:cover" />
        <div class="p-3">
          <div class="font-bold text-slate-800 text-sm">\${v.name}</div>
          <div style="font-size:11px;color:#64748b">\${v.city}</div>
          <div style="font-weight:800;color:#4f46e5;margin-top:4px">\${v.pricePerDay} MAD/j</div>
        </div>
      </div>\`).join('')
    : '<div class="col-span-full text-center py-8 text-slate-400">Aucun véhicule disponible</div>'
}

function selectVehicleForBooking(id) {
  selectedVehicle = allVehicles.find(v => v.id === id)
  showTab('booking')
  goStep(2)
}

function goStep(n) {
  currentStep = n
  ;[1,2,3,4].forEach(i => {
    const el = document.getElementById(\`booking-step\${i}\`)
    const ind = document.getElementById(\`step\${i}-indicator\`)
    if (!el || !ind) return
    el.classList.toggle('hidden', i !== n)
    const circle = ind.querySelector('.step-circle')
    const label = ind.querySelector('span')
    if (i < n) { circle.className='step-circle done'; label.style.color='#10b981'; label.style.fontWeight='600' }
    else if (i === n) { circle.className='step-circle active'; label.style.color='#4f46e5'; label.style.fontWeight='700' }
    else { circle.className='step-circle pending'; label.style.color='#94a3b8'; label.style.fontWeight='400' }
  })

  if (n === 2 && selectedVehicle) {
    // Set min dates
    const today = new Date().toISOString().split('T')[0]
    document.getElementById('startDate').min = today
    document.getElementById('endDate').min = today
    document.getElementById('startDate').value = document.getElementById('startDate').value || today
    const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate()+1)
    document.getElementById('endDate').value = document.getElementById('endDate').value || tomorrow.toISOString().split('T')[0]
    document.getElementById('selectedVehicleInfo').innerHTML = \`
      <div class="flex items-center gap-3">
        <img src="\${selectedVehicle.image}" style="width:60px;height:60px;border-radius:10px;object-fit:cover" />
        <div>
          <div class="font-bold text-slate-800">\${selectedVehicle.name}</div>
          <div style="font-size:12px;color:#64748b">\${selectedVehicle.city} · \${selectedVehicle.fuelType}</div>
          <div style="font-weight:700;color:#4f46e5;font-size:14px;margin-top:2px">\${selectedVehicle.pricePerDay} MAD/j · \${selectedVehicle.pricePerHour} MAD/h</div>
        </div>
      </div>\`
    calculateCost()
  }
  if (n === 4) renderFinalSummary()
}

async function calculateCost() {
  if (!selectedVehicle) return
  const startDate = document.getElementById('startDate').value
  const endDate = document.getElementById('endDate').value
  const startTime = document.getElementById('startTime').value || '09:00'
  const endTime = document.getElementById('endTime').value || '09:00'
  if (!startDate || !endDate) return

  try {
    const res = await axios.get(\`\${API}/api/payments/commission-calc\`, {
      params: { vehicleId: selectedVehicle.id, startDate, endDate, startTime, endTime }
    })
    const p = res.data.data.pricing
    const d = res.data.data.duration
    document.getElementById('costPreview').classList.remove('hidden')
    document.getElementById('costBreakdown').innerHTML = \`
      <div class="flex justify-between text-sm"><span class="text-slate-500">Durée</span><span class="font-semibold">\${d.totalDays}j \${d.totalHours % 24}h</span></div>
      <div class="flex justify-between text-sm"><span class="text-slate-500">Coût de base</span><span class="font-semibold">\${p.baseCost} MAD</span></div>
      \${p.commissionRate > 0 ? \`<div class="flex justify-between text-sm"><span class="text-amber-600">\${p.commissionLabel}</span><span class="font-semibold text-amber-600">+\${p.commissionAmount} MAD</span></div>\` : ''}
      <div style="height:1px;background:#e2e8f0;margin:4px 0"></div>
      <div class="flex justify-between"><span class="font-bold text-slate-800">Total</span><span class="font-bold text-2xl text-indigo-600">\${p.totalCost} MAD</span></div>\`
    window._lastCost = p
  } catch(e) {}
}

function renderFinalSummary() {
  if (!selectedVehicle || !window._lastCost) return
  const p = window._lastCost
  const startDate = document.getElementById('startDate').value
  const endDate = document.getElementById('endDate').value
  document.getElementById('finalSummary').innerHTML = \`
    <div class="flex items-center gap-3 mb-3">
      <img src="\${selectedVehicle.image}" style="width:50px;height:50px;border-radius:8px;object-fit:cover" />
      <div>
        <div class="font-bold text-slate-800">\${selectedVehicle.name}</div>
        <div style="font-size:12px;color:#64748b">\${startDate} → \${endDate}</div>
      </div>
    </div>
    <div class="flex justify-between text-sm text-slate-600 mb-1"><span>Sous-total</span><span>\${p.baseCost} MAD</span></div>
    \${p.commissionRate > 0 ? \`<div class="flex justify-between text-sm mb-1"><span class="text-amber-600">Commission (\${(p.commissionRate*100).toFixed(0)}%)</span><span class="text-amber-600">+\${p.commissionAmount} MAD</span></div>\` : ''}
    <div style="height:1px;background:#e2e8f0;margin:8px 0"></div>
    <div class="flex justify-between font-bold"><span>Total à payer</span><span class="text-indigo-600 text-xl">\${p.totalCost} MAD</span></div>\`
}

function selectPayment(method) {
  selectedPayment = method
  ;['card','paypal','cash'].forEach(m => {
    const el = document.getElementById(\`pm-\${m}\`)
    if (m === method) { el.style.borderColor = m==='card'?'#6366f1':m==='paypal'?'#3b82f6':'#10b981'; el.style.background = m==='card'?'#f0f0ff':m==='paypal'?'#eff6ff':'#f0fdf4' }
    else { el.style.borderColor = 'transparent'; el.style.background = '#f8fafc' }
  })
  document.getElementById('cardFields').style.display = method === 'card' ? 'grid' : 'none'
}

function formatCard(el) {
  let v = el.value.replace(/\D/g,'').substring(0,16)
  el.value = v.replace(/(.{4})/g,'$1 ').trim()
}

async function submitBooking() {
  const btn = document.getElementById('payBtn')
  const userName = document.getElementById('userName').value.trim()
  const userEmail = document.getElementById('userEmail').value.trim()
  const userPhone = document.getElementById('userPhone').value.trim()
  if (!userName || !userEmail || !userPhone) { toast('Veuillez remplir tous vos informations (étape 3)', 'error'); goStep(3); return }
  if (!selectedVehicle) { toast('Aucun véhicule sélectionné', 'error'); return }

  btn.innerHTML = '<div class="loader"></div> Traitement...'
  btn.disabled = true
  try {
    // 1. Create booking
    const bookingRes = await axios.post(\`\${API}/api/bookings\`, {
      vehicleId: selectedVehicle.id,
      userName, userEmail, userPhone,
      startDate: document.getElementById('startDate').value,
      endDate: document.getElementById('endDate').value,
      startTime: document.getElementById('startTime').value,
      endTime: document.getElementById('endTime').value,
      paymentMethod: selectedPayment,
      notes: document.getElementById('bookingNotes').value
    })
    const booking = bookingRes.data.data

    // 2. Simulate payment
    const payRes = await axios.post(\`\${API}/api/payments/simulate\`, {
      bookingId: booking.id,
      method: selectedPayment,
      cardLast4: selectedPayment === 'card' ? (document.getElementById('cardNumber').value.replace(/\s/g,'').slice(-4) || '1234') : null
    })

    // Show confirmation
    showConfirmation(booking, payRes.data.transaction)
    toast('Réservation confirmée ! Paiement accepté 🎉', 'success')
  } catch(e) {
    toast(e.response?.data?.error || 'Erreur lors de la réservation', 'error')
  }
  btn.innerHTML = '<i class="fas fa-lock"></i> Confirmer & Payer'
  btn.disabled = false
}

function showConfirmation(booking, txn) {
  const qr = generateVisualQR(booking.qrCode)
  document.getElementById('confirmModalContent').innerHTML = \`
    <div class="text-center mb-6">
      <div style="width:64px;height:64px;border-radius:50%;background:linear-gradient(135deg,#10b981,#059669);display:flex;align-items:center;justify-content:center;margin:0 auto 12px">
        <i class="fas fa-check text-white text-2xl"></i>
      </div>
      <h2 class="text-2xl font-bold text-slate-800">Réservation Confirmée !</h2>
      <p style="color:#64748b;font-size:13px;margin-top:4px">Transaction \${txn.id}</p>
    </div>
    <div class="flex justify-center mb-6">
      <div class="qr-box">
        <div style="font-size:11px;font-weight:700;color:#1e1b4b;letter-spacing:2px">SMARTRENT</div>
        \${qr}
        <div style="font-size:10px;color:#64748b;font-family:monospace">\${booking.qrCode}</div>
      </div>
    </div>
    <div class="grid grid-cols-2 gap-3 mb-4" style="font-size:13px">
      <div style="background:#f8fafc;padding:12px;border-radius:10px">
        <div style="color:#94a3b8;font-size:11px">Véhicule</div>
        <div style="font-weight:600;color:#1e293b">\${selectedVehicle?.name || ''}</div>
      </div>
      <div style="background:#f8fafc;padding:12px;border-radius:10px">
        <div style="color:#94a3b8;font-size:11px">Montant payé</div>
        <div style="font-weight:700;color:#4f46e5;font-size:16px">\${txn.amount} MAD</div>
      </div>
      <div style="background:#f8fafc;padding:12px;border-radius:10px">
        <div style="color:#94a3b8;font-size:11px">Période</div>
        <div style="font-weight:600;color:#1e293b">\${booking.startDate} → \${booking.endDate}</div>
      </div>
      <div style="background:#f8fafc;padding:12px;border-radius:10px">
        <div style="color:#94a3b8;font-size:11px">Méthode</div>
        <div style="font-weight:600;color:#1e293b">\${txn.method.toUpperCase()}</div>
      </div>
    </div>
    <div class="flex items-center gap-2 p-3 rounded-xl mb-4" style="background:#eff6ff;border:1px solid #bfdbfe">
      <i class="fas fa-info-circle text-blue-500"></i>
      <span style="font-size:12px;color:#1d4ed8">Présentez ce QR code lors du retrait du véhicule</span>
    </div>
    <button class="btn btn-primary w-full justify-center" onclick="closeModal('confirmModal');showTab('vehicles')">
      <i class="fas fa-list"></i> Voir mes réservations
    </button>\`
  document.getElementById('confirmModal').classList.add('open')

  // Refresh data
  loadVehicles(); allBookings = []
}

function generateVisualQR(text) {
  // Deterministic pseudo-random grid based on text
  const hash = Array.from(text).reduce((h,c)=>((h<<5)-h)+c.charCodeAt(0),0)
  let cells = ''
  for(let i=0;i<100;i++) {
    const v = (hash ^ (i*2654435761)) & 1
    cells += \`<div class="qr-cell" style="background:\${v?'#1e1b4b':'#fff'}"></div>\`
  }
  return \`<div class="qr-grid" style="width:160px">\${cells}</div>\`
}

// ── Load Bookings ─────────────────────────────────────────────────────────
async function loadBookings() {
  if (!document.getElementById('bookingsList')) return
  document.getElementById('bookingsList').innerHTML = '<div class="text-center py-12"><div class="loader" style="border-color:#e2e8f0;border-top-color:#6366f1;width:32px;height:32px;border-width:3px"></div></div>'
  try {
    const res = await axios.get(\`\${API}/api/bookings\`)
    allBookings = res.data.data
    if (!allBookings.length) {
      document.getElementById('bookingsList').innerHTML = \`
        <div class="text-center py-16 card p-8">
          <i class="fas fa-calendar-xmark text-slate-300 text-5xl mb-4"></i>
          <div class="text-slate-500 font-semibold text-lg">Aucune réservation pour le moment</div>
          <p class="text-slate-400 text-sm mt-1">Commencez par réserver un véhicule</p>
          <button class="btn btn-primary mt-4" onclick="showTab('booking')"><i class="fas fa-plus"></i> Nouvelle location</button>
        </div>\`
      return
    }
    const statusLabel = { pending:'En attente', confirmed:'Confirmée', active:'En cours', completed:'Terminée', cancelled:'Annulée' }
    const statusChip = { pending:'chip-amber', confirmed:'chip-blue', active:'chip-green', completed:'chip-gray', cancelled:'chip-red' }
    const payChip = { pending:'chip-amber', paid:'chip-green', refunded:'chip-gray' }
    document.getElementById('bookingsList').innerHTML = allBookings.map(b => {
      const v = allVehicles.find(x=>x.id===b.vehicleId)
      return \`
      <div class="card p-5 flex flex-col sm:flex-row items-start gap-4">
        \${v ? \`<img src="\${v.image}" style="width:80px;height:80px;border-radius:12px;object-fit:cover;flex-shrink:0" />\` : '<div style="width:80px;height:80px;background:#f1f5f9;border-radius:12px;flex-shrink:0"></div>'}
        <div style="flex:1;min-width:0">
          <div class="flex items-center gap-2 flex-wrap mb-1">
            <span class="font-bold text-slate-800" style="font-size:15px">\${v?.name || b.vehicleId}</span>
            <span class="chip \${statusChip[b.status]}">\${statusLabel[b.status]}</span>
            <span class="chip \${payChip[b.paymentStatus]}">\${b.paymentStatus}</span>
          </div>
          <div style="font-size:12px;color:#64748b;margin-bottom:6px">\${b.userName} · \${b.userEmail}</div>
          <div class="flex flex-wrap gap-3" style="font-size:12px;color:#374151">
            <span><i class="fas fa-calendar text-indigo-400 mr-1"></i>\${b.startDate} → \${b.endDate}</span>
            <span><i class="fas fa-clock text-indigo-400 mr-1"></i>\${b.totalHours}h (\${b.totalDays}j)</span>
            <span><i class="fas fa-money-bill text-green-500 mr-1"></i>\${b.totalCost} MAD</span>
            \${b.commissionRate > 0 ? \`<span class="text-amber-600"><i class="fas fa-percent mr-1"></i>Commission: \${(b.commissionRate*100).toFixed(0)}% (+\${b.commissionAmount} MAD)</span>\` : ''}
          </div>
        </div>
        <div class="flex flex-col gap-2 flex-shrink-0">
          <div style="font-family:monospace;font-size:10px;background:#f0f0ff;color:#4338ca;padding:4px 8px;border-radius:6px;text-align:center">\${b.qrCode.substring(0,18)}</div>
          \${b.status !== 'cancelled' && b.status !== 'completed' ? \`
            <button class="btn btn-danger py-1 px-3" style="font-size:12px" onclick="cancelBooking('\${b.id}')">
              <i class="fas fa-xmark"></i> Annuler
            </button>\` : ''}
        </div>
      </div>\`
    }).join('')
  } catch(e) { toast('Erreur chargement réservations', 'error') }
}

async function cancelBooking(id) {
  if (!confirm('Annuler cette réservation ?')) return
  try {
    await axios.patch(\`\${API}/api/bookings/\${id}/cancel\`)
    toast('Réservation annulée', 'info')
    loadBookings(); loadVehicles()
  } catch(e) { toast(e.response?.data?.error || 'Erreur', 'error') }
}

// ── GPS ───────────────────────────────────────────────────────────────────
async function loadGPS() {
  // Vehicle GPS statuses
  const statusHtml = allVehicles.map(v => \`
    <div class="flex items-center gap-3 p-3 rounded-xl" style="background:#f8fafc">
      <div class="gps-dot \${v.gpsStatus}"></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:13px;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">\${v.name}</div>
        <div style="font-size:11px;color:#64748b">\${v.city}</div>
      </div>
      <span class="chip \${v.gpsStatus==='online'?'chip-green':v.gpsStatus==='offline'?'chip-red':'chip-amber'}">\${v.gpsStatus}</span>
    </div>\`).join('')
  document.getElementById('vehicleGPSStatuses').innerHTML = statusHtml

  // GPS vehicle selector
  document.getElementById('gpsVehicleSelect').innerHTML = '<option value="">-- Choisir --</option>' +
    allVehicles.map(v => \`<option value="\${v.id}">\${v.name} (\${v.city})</option>\`).join('')

  // Alerts
  try {
    const res = await axios.get(\`\${API}/api/gps/alerts?resolved=false\`)
    const alerts = res.data.data
    document.getElementById('gps-badge').classList.toggle('hidden', alerts.length === 0)
    document.getElementById('gpsAlertsList').innerHTML = alerts.length
      ? alerts.map(a => \`
        <div class="p-3 rounded-xl" style="background:#fef3c7;border:1px solid #fcd34d">
          <div class="flex items-start justify-between gap-2 mb-2">
            <div>
              <div style="font-weight:700;font-size:13px;color:#92400e"><i class="fas fa-triangle-exclamation mr-1"></i>Écart GPS</div>
              <div style="font-size:11px;color:#78350f">\${a.description}</div>
            </div>
            <button class="btn py-1 px-2" style="font-size:11px;background:#10b981;color:white;flex-shrink:0" onclick="resolveAlert('\${a.id}')">Résoudre</button>
          </div>
          <div style="font-size:11px;color:#92400e"><i class="fas fa-route mr-1"></i>\${a.distance}m d'écart</div>
        </div>\`).join('')
      : '<div class="text-center py-6 text-slate-400"><i class="fas fa-check-circle text-green-400 text-3xl mb-2 block"></i><div style="font-size:13px">Aucune alerte GPS active</div></div>'
  } catch(e) {}
}

function detectAndValidate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      document.getElementById('deviceLat').value = pos.coords.latitude.toFixed(5)
      document.getElementById('deviceLng').value = pos.coords.longitude.toFixed(5)
      toast('Position détectée !', 'success')
    }, () => {
      // Casablanca fallback
      document.getElementById('deviceLat').value = '33.5731'
      document.getElementById('deviceLng').value = '-7.5898'
      toast('Position simulée (Casablanca)', 'info')
    })
  }
}

async function validateGPS() {
  const vehicleId = document.getElementById('gpsVehicleSelect').value
  const deviceLat = parseFloat(document.getElementById('deviceLat').value)
  const deviceLng = parseFloat(document.getElementById('deviceLng').value)
  if (!vehicleId || !deviceLat || !deviceLng) { toast('Sélectionnez un véhicule et entrez votre position', 'error'); return }
  try {
    const res = await axios.post(\`\${API}/api/gps/validate\`, { vehicleId, deviceLat, deviceLng })
    const d = res.data
    const colors = { ok:'#dcfce7;border-color:#86efac', warning:'#fef3c7;border-color:#fcd34d', mismatch:'#fee2e2;border-color:#fca5a5' }
    const icons = { ok:'fa-check-circle text-green-600', warning:'fa-triangle-exclamation text-amber-500', mismatch:'fa-circle-xmark text-red-500' }
    const resultEl = document.getElementById('gpsResult')
    resultEl.classList.remove('hidden')
    resultEl.style = \`background:\${colors[d.status]};border:1.5px solid\`
    resultEl.innerHTML = \`
      <div class="flex items-start gap-2 mb-2">
        <i class="fas \${icons[d.status]} text-lg flex-shrink-0 mt-0.5"></i>
        <div>
          <div style="font-weight:700;font-size:13px">\${d.message}</div>
          <div style="font-size:11px;color:#64748b;margin-top:2px">Distance : \${d.distance}m</div>
        </div>
      </div>
      \${d.directions ? \`<a href="\${d.directions.googleMaps}" target="_blank" class="btn btn-primary py-1 px-3" style="font-size:12px"><i class="fas fa-map-marked-alt"></i> Itinéraire Google Maps</a>\` : ''}\`
  } catch(e) { toast('Erreur validation GPS', 'error') }
}

async function resolveAlert(id) {
  try {
    await axios.patch(\`\${API}/api/gps/alerts/\${id}/resolve\`)
    toast('Alerte résolue ✓', 'success')
    loadGPS(); loadVehicles()
  } catch(e) { toast('Erreur', 'error') }
}

// ── Payments Tab ──────────────────────────────────────────────────────────
async function loadPayments() {
  // Commission simulator vehicle select
  document.getElementById('simVehicle').innerHTML = '<option value="">-- Choisir --</option>' +
    allVehicles.map(v => \`<option value="\${v.id}">\${v.name}</option>\`).join('')

  // Set today's dates
  const today = new Date().toISOString().split('T')[0]
  const nextWeek = new Date(); nextWeek.setDate(nextWeek.getDate()+3)
  document.getElementById('simStart').value = today
  document.getElementById('simEnd').value = nextWeek.toISOString().split('T')[0]

  // Revenue chart
  try {
    const res = await axios.get(\`\${API}/api/payments/summary\`)
    const d = res.data.data
    const ctx = document.getElementById('revenueChart')
    if (window._revenueChart) window._revenueChart.destroy()
    window._revenueChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: d.byVehicle.map(v => v.vehicleName.substring(0,15)),
        datasets: [
          { label: 'Revenu (MAD)', data: d.byVehicle.map(v=>v.revenue), backgroundColor: 'rgba(99,102,241,.8)', borderRadius: 6 },
          { label: 'Commissions (MAD)', data: d.byVehicle.map(v=>v.commissions), backgroundColor: 'rgba(245,158,11,.8)', borderRadius: 6 }
        ]
      },
      options: { responsive:true, plugins:{legend:{position:'top'}}, scales:{y:{beginAtZero:true}} }
    })
  } catch(e) {}

  // Transactions
  const paid = allBookings.filter(b=>b.paymentStatus==='paid')
  document.getElementById('transactionsList').innerHTML = paid.length
    ? paid.map(b => {
        const v = allVehicles.find(x=>x.id===b.vehicleId)
        return \`
        <div class="flex items-center gap-4 p-4 rounded-xl" style="background:#f8fafc;border:1px solid #e2e8f0">
          \${v ? \`<img src="\${v.image}" style="width:48px;height:48px;border-radius:8px;object-fit:cover;flex-shrink:0" />\` : '<div style="width:48px;height:48px;background:#e2e8f0;border-radius:8px;flex-shrink:0"></div>'}
          <div style="flex:1">
            <div style="font-weight:700;font-size:14px;color:#1e293b">\${v?.name || b.vehicleId}</div>
            <div style="font-size:12px;color:#64748b">\${b.userName} · \${b.paymentMethod.toUpperCase()}</div>
          </div>
          <div class="text-right">
            <div style="font-weight:800;color:#4f46e5;font-size:16px">\${b.totalCost} MAD</div>
            \${b.commissionAmount > 0 ? \`<div style="font-size:11px;color:#f59e0b">Commission: \${b.commissionAmount} MAD</div>\` : ''}
          </div>
        </div>\`
      }).join('')
    : '<div class="text-center py-8 text-slate-400">Aucune transaction</div>'
}

async function simulateCommission() {
  const vehicleId = document.getElementById('simVehicle').value
  const startDate = document.getElementById('simStart').value
  const endDate = document.getElementById('simEnd').value
  if (!vehicleId || !startDate || !endDate) return
  try {
    const res = await axios.get(\`\${API}/api/payments/commission-calc\`, { params: { vehicleId, startDate, endDate } })
    const p = res.data.data.pricing
    const d = res.data.data.duration
    const el = document.getElementById('commissionResult')
    el.classList.remove('hidden')
    el.innerHTML = \`
      <div style="font-size:12px;font-weight:700;color:#4338ca;margin-bottom:8px">Estimation</div>
      <div class="flex justify-between text-sm mb-1"><span>Durée</span><span class="font-semibold">\${d.totalDays}j \${d.totalHours%24}h</span></div>
      <div class="flex justify-between text-sm mb-1"><span>Coût de base</span><span>\${p.baseCost} MAD</span></div>
      \${p.commissionRate > 0 ? \`<div class="flex justify-between text-sm mb-1 text-amber-700"><span>\${p.commissionLabel}</span><span>+\${p.commissionAmount} MAD</span></div>\` : '<div class="text-sm text-green-700 mb-1">Pas de commission (&lt;24h)</div>'}
      <div style="height:1px;background:#c7d2fe;margin:6px 0"></div>
      <div class="flex justify-between font-bold"><span>Total</span><span style="color:#4f46e5;font-size:16px">\${p.totalCost} MAD</span></div>\`
  } catch(e) {}
}

// ── Dashboard ─────────────────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const statsRes = await axios.get(\`\${API}/api/stats\`)
    stats = statsRes.data.data
    const metrics = [
      { label:'Véhicules', value: stats.totalVehicles, icon:'fa-car', color:'#6366f1', bg:'#e0e7ff' },
      { label:'Disponibles', value: stats.availableVehicles, icon:'fa-circle-check', color:'#10b981', bg:'#dcfce7' },
      { label:'Réservations actives', value: stats.activeBookings, icon:'fa-calendar-check', color:'#3b82f6', bg:'#dbeafe' },
      { label:'Revenus total', value: stats.totalRevenue+' MAD', icon:'fa-money-bill-trend-up', color:'#f59e0b', bg:'#fef3c7' },
      { label:'Alertes GPS', value: stats.gpsWarnings, icon:'fa-satellite-dish', color: stats.gpsWarnings > 0 ? '#ef4444':'#10b981', bg: stats.gpsWarnings > 0 ? '#fee2e2':'#dcfce7' },
      { label:'Propriétaires', value: stats.totalOwners, icon:'fa-users', color:'#8b5cf6', bg:'#ede9fe' },
    ]
    document.getElementById('metricsGrid').innerHTML = metrics.map(m => \`
      <div class="stat-card">
        <div class="metric-icon mb-3" style="background:\${m.bg}">
          <i class="fas \${m.icon}" style="color:\${m.color}"></i>
        </div>
        <div style="font-size:22px;font-weight:800;color:#1e293b">\${m.value}</div>
        <div style="font-size:12px;color:#64748b;font-weight:500">\${m.label}</div>
      </div>\`).join('')

    // Booking status donut
    const byCounts = { pending:0, confirmed:0, active:0, completed:0, cancelled:0 }
    allBookings.forEach(b => { if(byCounts[b.status]!==undefined) byCounts[b.status]++ })
    const ctx1 = document.getElementById('bookingStatusChart')
    if (window._statusChart) window._statusChart.destroy()
    window._statusChart = new Chart(ctx1, {
      type: 'doughnut',
      data: {
        labels: ['En attente','Confirmée','En cours','Terminée','Annulée'],
        datasets: [{ data: Object.values(byCounts), backgroundColor:['#f59e0b','#3b82f6','#10b981','#6366f1','#ef4444'], borderWidth:0 }]
      },
      options: { responsive:true, plugins:{legend:{position:'bottom'}}, cutout:'65%' }
    })

    // Vehicle type pie
    const byType = {}
    allVehicles.forEach(v => { byType[v.type] = (byType[v.type]||0)+1 })
    const ctx2 = document.getElementById('vehicleTypeChart')
    if (window._typeChart) window._typeChart.destroy()
    window._typeChart = new Chart(ctx2, {
      type: 'pie',
      data: {
        labels: Object.keys(byType),
        datasets: [{ data: Object.values(byType), backgroundColor:['#6366f1','#f59e0b','#10b981','#3b82f6'], borderWidth:0 }]
      },
      options: { responsive:true, plugins:{legend:{position:'bottom'}} }
    })

    // Top vehicles
    const top = [...allVehicles].sort((a,b)=>b.totalRentals-a.totalRentals).slice(0,5)
    document.getElementById('topVehicles').innerHTML = top.map((v,i) => \`
      <div class="flex items-center gap-4 p-3 rounded-xl" style="background:\${i===0?'#fef3c7':i===1?'#f1f5f9':i===2?'#fef9f0':'#f8fafc'}">
        <div style="font-size:18px;font-weight:900;width:28px;text-align:center;color:\${i===0?'#f59e0b':i===1?'#94a3b8':'#94a3b8'}">\${i===0?'🥇':i===1?'🥈':i===2?'🥉':i+1}</div>
        <img src="\${v.image}" style="width:44px;height:44px;border-radius:10px;object-fit:cover;flex-shrink:0" />
        <div style="flex:1">
          <div style="font-weight:700;font-size:14px;color:#1e293b">\${v.name}</div>
          <div style="font-size:12px;color:#64748b">\${v.city} · ⭐ \${v.rating}</div>
        </div>
        <div class="text-right">
          <div style="font-weight:700;color:#4f46e5">\${v.totalRentals} locations</div>
          <div style="font-size:11px;color:#94a3b8">\${v.pricePerDay} MAD/j</div>
        </div>
      </div>\`).join('')
  } catch(e) { console.error(e) }
}

// ── Location detection ────────────────────────────────────────────────────
function detectLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      userLat = pos.coords.latitude
      userLng = pos.coords.longitude
      document.getElementById('userLocationLabel').textContent = \`\${userLat.toFixed(4)}, \${userLng.toFixed(4)}\`
      toast('Position détectée !', 'success')
    }, () => {
      userLat = 33.5731; userLng = -7.5898
      document.getElementById('userLocationLabel').textContent = 'Casablanca (simulée)'
      toast('Position simulée (Casablanca)', 'info')
    })
  }
}

// ── Search ────────────────────────────────────────────────────────────────
function handleSearch(q) {
  if (!q) { renderVehiclesGrid(); return }
  const filtered = allVehicles.filter(v =>
    v.name.toLowerCase().includes(q.toLowerCase()) ||
    v.city.toLowerCase().includes(q.toLowerCase()) ||
    v.type.toLowerCase().includes(q.toLowerCase()) ||
    v.brand.toLowerCase().includes(q.toLowerCase())
  )
  const g = document.getElementById('vehiclesGrid')
  g.innerHTML = filtered.length ? filtered.map(v => vehicleCard(v)).join('') : '<div class="col-span-full text-center py-8 text-slate-400">Aucun résultat</div>'
}

// ── Init ──────────────────────────────────────────────────────────────────
async function init() {
  await loadVehicles()
  await loadBookings()
  // Pre-populate GPS vehicle selector
  if(document.getElementById('gpsVehicleSelect')) {
    document.getElementById('gpsVehicleSelect').innerHTML = '<option value="">-- Choisir --</option>' +
      allVehicles.map(v=>\`<option value="\${v.id}">\${v.name} (\${v.city})</option>\`).join('')
  }
}

init()
</script>
</body>
</html>`)
})

export default app
