// ─── SmartRent – In-Memory Data Store ───────────────────────────────────────
// (Used for demo / local dev – replace with D1 for production)

export interface Vehicle {
  id: string
  name: string
  type: 'car' | 'bike' | 'scooter' | 'van'
  brand: string
  model: string
  year: number
  pricePerDay: number  // MAD
  pricePerHour: number // MAD
  lat: number
  lng: number
  address: string
  city: string
  available: boolean
  image: string
  features: string[]
  ownerId: string
  rating: number
  totalRentals: number
  gpsStatus: 'online' | 'offline' | 'warning'
  licensePlate: string
  fuelType: 'essence' | 'diesel' | 'electrique' | 'hybride' | 'N/A'
}

export interface Booking {
  id: string
  vehicleId: string
  userId: string
  userName: string
  userEmail: string
  userPhone: string
  startDate: string
  endDate: string
  startTime: string
  endTime: string
  totalHours: number
  totalDays: number
  baseCost: number
  commissionRate: number
  commissionAmount: number
  totalCost: number
  status: 'pending' | 'confirmed' | 'active' | 'completed' | 'cancelled'
  paymentStatus: 'pending' | 'paid' | 'refunded'
  paymentMethod: 'card' | 'paypal' | 'cash'
  qrCode: string
  contractUrl: string
  createdAt: string
  isAdvanceBooking: boolean   // > 24h ahead
  pickupLat: number
  pickupLng: number
  notes: string
}

export interface Owner {
  id: string
  name: string
  email: string
  phone: string
  city: string
  verified: boolean
  totalVehicles: number
  totalRevenue: number
  rating: number
  joinedAt: string
}

export interface GpsAlert {
  id: string
  vehicleId: string
  type: 'mismatch' | 'offline' | 'geofence' | 'resolved'
  description: string
  vehicleLat: number
  vehicleLng: number
  expectedLat: number
  expectedLng: number
  distance: number  // metres
  resolved: boolean
  createdAt: string
}

// ─── Seed Data ────────────────────────────────────────────────────────────────

export const vehicles: Vehicle[] = [
  {
    id: 'v1', name: 'Dacia Logan', type: 'car', brand: 'Dacia', model: 'Logan',
    year: 2022, pricePerDay: 280, pricePerHour: 40,
    lat: 33.5731, lng: -7.5898, address: 'Bd Mohammed V, Centre', city: 'Casablanca',
    available: true,
    image: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=400&q=80',
    features: ['Climatisation', 'GPS', 'Bluetooth', 'Assurance incluse'],
    ownerId: 'o1', rating: 4.7, totalRentals: 142,
    gpsStatus: 'online', licensePlate: 'A-12345-CA',
    fuelType: 'essence'
  },
  {
    id: 'v2', name: 'Renault Clio', type: 'car', brand: 'Renault', model: 'Clio',
    year: 2023, pricePerDay: 350, pricePerHour: 50,
    lat: 33.5892, lng: -7.6031, address: 'Maârif, Rue Normandie', city: 'Casablanca',
    available: true,
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400&q=80',
    features: ['Climatisation', 'GPS', 'Caméra de recul', 'Bluetooth'],
    ownerId: 'o2', rating: 4.9, totalRentals: 89,
    gpsStatus: 'online', licensePlate: 'B-67890-CA',
    fuelType: 'essence'
  },
  {
    id: 'v3', name: 'Yamaha MT-07', type: 'bike', brand: 'Yamaha', model: 'MT-07',
    year: 2021, pricePerDay: 200, pricePerHour: 30,
    lat: 33.5950, lng: -7.6200, address: 'Ain Diab, Corniche', city: 'Casablanca',
    available: true,
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80',
    features: ['GPS intégré', 'Casque fourni', 'Assurance incluse'],
    ownerId: 'o1', rating: 4.5, totalRentals: 67,
    gpsStatus: 'online', licensePlate: 'C-11111-CA',
    fuelType: 'essence'
  },
  {
    id: 'v4', name: 'Tesla Model 3', type: 'car', brand: 'Tesla', model: 'Model 3',
    year: 2023, pricePerDay: 600, pricePerHour: 85,
    lat: 33.5650, lng: -7.6100, address: 'Anfa, Place de la Ligue Arabe', city: 'Casablanca',
    available: false,
    image: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=400&q=80',
    features: ['Électrique', 'Autopilot', 'Superchargeur', 'GPS avancé'],
    ownerId: 'o3', rating: 5.0, totalRentals: 34,
    gpsStatus: 'online', licensePlate: 'D-99999-CA',
    fuelType: 'electrique'
  },
  {
    id: 'v5', name: 'Citroën Berlingo', type: 'van', brand: 'Citroën', model: 'Berlingo',
    year: 2022, pricePerDay: 420, pricePerHour: 60,
    lat: 33.5800, lng: -7.5750, address: 'Derb Sultan, Hay Hassani', city: 'Casablanca',
    available: true,
    image: 'https://images.unsplash.com/photo-1568844293986-8d0400bd4745?w=400&q=80',
    features: ['Grand coffre', 'GPS', 'Climatisation', '5 places'],
    ownerId: 'o2', rating: 4.3, totalRentals: 55,
    gpsStatus: 'warning', licensePlate: 'E-22222-CA',
    fuelType: 'diesel'
  },
  {
    id: 'v6', name: 'Trottinette Électrique', type: 'scooter', brand: 'Xiaomi', model: 'Pro 2',
    year: 2023, pricePerDay: 80, pricePerHour: 15,
    lat: 33.5780, lng: -7.5950, address: 'Bd Zerktouni, Centre', city: 'Casablanca',
    available: true,
    image: 'https://images.unsplash.com/photo-1572155376062-9e39ac278ed4?w=400&q=80',
    features: ['Électrique', 'Pliable', 'App connectée', 'Casque fourni'],
    ownerId: 'o3', rating: 4.6, totalRentals: 210,
    gpsStatus: 'online', licensePlate: 'N/A',
    fuelType: 'electrique'
  },
  {
    id: 'v7', name: 'Volkswagen Golf', type: 'car', brand: 'Volkswagen', model: 'Golf',
    year: 2022, pricePerDay: 380, pricePerHour: 55,
    lat: 34.0209, lng: -6.8416, address: 'Avenue Hassan II', city: 'Rabat',
    available: true,
    image: 'https://images.unsplash.com/photo-1471479917192-1a29a562b24b?w=400&q=80',
    features: ['Climatisation', 'GPS', 'Toit ouvrant', 'Bluetooth'],
    ownerId: 'o1', rating: 4.8, totalRentals: 78,
    gpsStatus: 'online', licensePlate: 'A-55555-RA',
    fuelType: 'essence'
  },
  {
    id: 'v8', name: 'Honda CB500', type: 'bike', brand: 'Honda', model: 'CB500',
    year: 2021, pricePerDay: 180, pricePerHour: 28,
    lat: 31.6295, lng: -7.9811, address: 'Guéliz, Avenue Mohammed VI', city: 'Marrakech',
    available: true,
    image: 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=400&q=80',
    features: ['GPS', 'Casque fourni', 'Assurance incluse', 'Carte touristique'],
    ownerId: 'o2', rating: 4.4, totalRentals: 95,
    gpsStatus: 'online', licensePlate: 'B-44444-MA',
    fuelType: 'essence'
  }
]

export const bookings: Booking[] = [
  {
    id: 'b1', vehicleId: 'v1', userId: 'u1',
    userName: 'Youssef El Mansouri', userEmail: 'youssef@example.ma', userPhone: '+212612345678',
    startDate: '2026-02-22', endDate: '2026-02-24', startTime: '09:00', endTime: '09:00',
    totalHours: 48, totalDays: 2, baseCost: 560,
    commissionRate: 0.12, commissionAmount: 67.2, totalCost: 627.2,
    status: 'confirmed', paymentStatus: 'paid', paymentMethod: 'card',
    qrCode: 'QR-B1-2026', contractUrl: '/contracts/b1.pdf',
    createdAt: '2026-02-20T10:30:00Z', isAdvanceBooking: true,
    pickupLat: 33.5731, pickupLng: -7.5898, notes: ''
  },
  {
    id: 'b2', vehicleId: 'v3', userId: 'u2',
    userName: 'Fatima Zahra Benali', userEmail: 'fatima@example.ma', userPhone: '+212698765432',
    startDate: '2026-02-21', endDate: '2026-02-21', startTime: '14:00', endTime: '20:00',
    totalHours: 6, totalDays: 0, baseCost: 180,
    commissionRate: 0, commissionAmount: 0, totalCost: 180,
    status: 'active', paymentStatus: 'paid', paymentMethod: 'paypal',
    qrCode: 'QR-B2-2026', contractUrl: '/contracts/b2.pdf',
    createdAt: '2026-02-21T13:45:00Z', isAdvanceBooking: false,
    pickupLat: 33.5950, pickupLng: -7.6200, notes: 'Retour à Ain Diab'
  }
]

export const owners: Owner[] = [
  {
    id: 'o1', name: 'AutoLoc Casablanca', email: 'contact@autoloc.ma',
    phone: '+212522123456', city: 'Casablanca', verified: true,
    totalVehicles: 3, totalRevenue: 45800, rating: 4.7, joinedAt: '2024-01-15'
  },
  {
    id: 'o2', name: 'Mohamed Tazi', email: 'mtazi@example.ma',
    phone: '+212661234567', city: 'Casablanca', verified: true,
    totalVehicles: 3, totalRevenue: 28500, rating: 4.6, joinedAt: '2024-03-10'
  },
  {
    id: 'o3', name: 'GreenDrive Morocco', email: 'info@greendrive.ma',
    phone: '+212534567890', city: 'Casablanca', verified: true,
    totalVehicles: 2, totalRevenue: 19200, rating: 4.8, joinedAt: '2024-06-01'
  }
]

export const gpsAlerts: GpsAlert[] = [
  {
    id: 'g1', vehicleId: 'v5', type: 'mismatch',
    description: 'Position GPS ne correspond pas à la localisation déclarée',
    vehicleLat: 33.5825, vehicleLng: -7.5800,
    expectedLat: 33.5800, expectedLng: -7.5750,
    distance: 412, resolved: false, createdAt: '2026-02-20T08:15:00Z'
  }
]

// ─── Utility Functions ────────────────────────────────────────────────────────

export function generateId(prefix: string): string {
  return `${prefix}${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
}

export function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))
}

export function calculateCommission(baseCost: number, isAdvance: boolean, hours: number) {
  if (!isAdvance || hours < 24) return { rate: 0, amount: 0 }
  // 10% pour 24–48h, 12% pour 48–72h, 15% au-delà
  const rate = hours >= 72 ? 0.15 : hours >= 48 ? 0.12 : 0.10
  return { rate, amount: Math.round(baseCost * rate * 100) / 100 }
}

export function generateQRCode(bookingId: string): string {
  return `SMARTRENT-${bookingId.toUpperCase()}-${Date.now().toString(36).toUpperCase()}`
}
